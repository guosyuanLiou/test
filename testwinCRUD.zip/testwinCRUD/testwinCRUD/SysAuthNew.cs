﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testwinCRUD
{
    public partial class SysAuthNew : Form
    {
        public SysAuthNew()
        {
            InitializeComponent();
        }
        int handout = 0;
        private void textBox5_Click(object sender, EventArgs e)
        {
            this.monthCalendar1.Visible = true;
            handout = 1;
        }

        private void textBox6_Click(object sender, EventArgs e)
        {
            this.monthCalendar1.Visible = true;
            handout = 2;
        }

        private void SysAuthNew_Load(object sender, EventArgs e)
        {
            this.monthCalendar1.Visible = false;
        }

        private void monthCalendar1_DateSelected(object sender, DateRangeEventArgs e)
        {
            if (1 == handout)
                textBox5.Text = monthCalendar1.SelectionEnd.Date.ToLongDateString().ToString();
            else if(2 == handout)
                textBox6.Text = monthCalendar1.SelectionEnd.Date.ToLongDateString().ToString();
            this.monthCalendar1.Visible = false;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
