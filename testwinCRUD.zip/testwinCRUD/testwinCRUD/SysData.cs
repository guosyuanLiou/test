﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;

namespace testwinCRUD
{
    public partial class SysData : Form
    {
        public SysData()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (comboBox1.SelectedIndex ==0)
            //{
            //    string sql = "select seq, item_value from data where item_name = 'contain'";
            //    DataTable dt = GetOleDbDataTable("C:\\wk\\testwinCRUD\\testwinCRUD\\db1.mdb", sql);
            //    dataGridView1.DataSource = dt;
            //}
            //else if (comboBox1.SelectedIndex == 1)
            //{
            //    string sql = "select seq, item_value from data where item_name = 'area'";
            //    DataTable dt = GetOleDbDataTable("C:\\wk\\testwinCRUD\\testwinCRUD\\db1.mdb", sql);
            //    dataGridView1.DataSource = dt;
            //}

            //dataGridView1.AutoResizeRows((dataGridView1.RowCount);
            //dataGridView1.AutoResizeColumns(dataGridView1.ColumnCount);
        }

        private void SysData_Load(object sender, EventArgs e)
        {
            // TODO: 這行程式碼會將資料載入 'db1DataSet.data' 資料表。您可以視需要進行移動或移除。
            //this.dataTableAdapter.Fill(this.db1DataSet.data);
            string sql = "select DISTINCT item_name from data ";
            DataTable dt = GetOleDbDataTable("C:\\wk\\testwinCRUD\\testwinCRUD\\db1.mdb", sql);
            dataGridView1.DataSource = dt;
        }
        public static void OleDbInsertUpdateDelete(string Database, string OleDbSelectString)
        {
            string cnstr = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Database);
            OleDbConnection icn = OleDbOpenConn(cnstr);
            OleDbCommand cmd = new OleDbCommand(OleDbSelectString, icn);
            cmd.ExecuteNonQuery();
            if (icn.State == ConnectionState.Open) icn.Close();
        }
        public static DataTable GetOleDbDataTable(string Database, string OleDbString)
        {
            DataTable myDataTable = new DataTable();
            OleDbConnection icn = OleDbOpenConn(Database);
            OleDbDataAdapter da = new OleDbDataAdapter(OleDbString, icn);
            DataSet ds = new DataSet();
            ds.Clear();
            da.Fill(ds);
            myDataTable = ds.Tables[0];
            if (icn.State == ConnectionState.Open) icn.Close();
            return myDataTable;
        }
        public static OleDbConnection OleDbOpenConn(string Database)
        {
            string cnstr = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Database);
            OleDbConnection icn = new OleDbConnection();
            icn.ConnectionString = cnstr;
            if (icn.State == ConnectionState.Open) icn.Close();
            icn.Open();
            return icn;
        }

        private void dataGridView1_Layout(object sender, LayoutEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            SysDataNew sysDNew = new SysDataNew();
            sysDNew.ShowDialog();
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            int Row = dataGridView1.CurrentCell.RowIndex;
            //textBox8.Text = dataGridView1.Rows[Row].Cells[0].Value.ToString();
            //textBox7.Text = dataGridView1.Rows[Row].Cells[1].Value.ToString();
            textBox5.Text = dataGridView1.Rows[Row].Cells[0].Value.ToString();
            //textBox6.Text = dataGridView1.Rows[Row].Cells[1].Value.ToString();
            string strSQL = dataGridView1.Rows[Row].Cells[0].Value.ToString();

            string sql = "select item_value,lm_time,lm_user from data where item_name = '"+strSQL+"'";
            DataTable dt = GetOleDbDataTable("C:\\wk\\testwinCRUD\\testwinCRUD\\db1.mdb", sql);
            dataGridView2.DataSource = dt;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_Paint(object sender, PaintEventArgs e)
        {
            //int Row = dataGridView1.Rows.Count;
            //int column = dataGridView1.ColumnCount;
            //for(int j = 0;j< Row-1;j++)
            //if (dataGridView1.Rows[j].Cells[0].Value.ToString() == "contain")
            //{
            //    for(int i = 0; i < column; i++)
            //        dataGridView1.Rows[j].Cells[i].Style.BackColor = Color.LightBlue;
            //}
            //else
            //{
            //    for (int i = 0; i < column; i++)
            //        dataGridView1.Rows[j].Cells[i].Style.BackColor = Color.LightGreen;
            //}
            
        }

        private void dataGridView2_Click(object sender, EventArgs e)
        {
            int Row = dataGridView2.CurrentCell.RowIndex;
            //textBox8.Text = dataGridView1.Rows[Row].Cells[0].Value.ToString();
            //textBox7.Text = dataGridView2.Rows[Row].Cells[0].Value.ToString();
            //textBox5.Text = dataGridView1.Rows[Row].Cells[0].Value.ToString();
            textBox6.Text = dataGridView2.Rows[Row].Cells[0].Value.ToString();
        }
    }
}
