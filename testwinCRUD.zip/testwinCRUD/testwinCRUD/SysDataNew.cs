﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testwinCRUD
{
    public partial class SysDataNew : Form
    {
        public SysDataNew()
        {
            InitializeComponent();
        }

        private void SysDataNew_Load(object sender, EventArgs e)
        {
            string sql = "select item_name from data where seq = 1";
            DataTable dt = GetOleDbDataTable("C:\\wk\\testwinCRUD\\testwinCRUD\\db1.mdb", sql);
            dataGridView1.DataSource = dt;

            string sql2 = "select item_value from data where item_name = 'contain'";
            DataTable dt2 = GetOleDbDataTable("C:\\wk\\testwinCRUD\\testwinCRUD\\db1.mdb", sql2);
            dataGridView2.DataSource = dt2;
        }
        public static void OleDbInsertUpdateDelete(string Database, string OleDbSelectString)
        {
            string cnstr = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Database);
            OleDbConnection icn = OleDbOpenConn(cnstr);
            OleDbCommand cmd = new OleDbCommand(OleDbSelectString, icn);
            cmd.ExecuteNonQuery();
            if (icn.State == ConnectionState.Open) icn.Close();
        }
        public static DataTable GetOleDbDataTable(string Database, string OleDbString)
        {
            DataTable myDataTable = new DataTable();
            OleDbConnection icn = OleDbOpenConn(Database);
            OleDbDataAdapter da = new OleDbDataAdapter(OleDbString, icn);
            DataSet ds = new DataSet();
            ds.Clear();
            da.Fill(ds);
            myDataTable = ds.Tables[0];
            if (icn.State == ConnectionState.Open) icn.Close();
            return myDataTable;
        }
        public static OleDbConnection OleDbOpenConn(string Database)
        {
            string cnstr = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Database);
            OleDbConnection icn = new OleDbConnection();
            icn.ConnectionString = cnstr;
            if (icn.State == ConnectionState.Open) icn.Close();
            icn.Open();
            return icn;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
