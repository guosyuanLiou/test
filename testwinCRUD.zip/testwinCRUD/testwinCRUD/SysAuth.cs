﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testwinCRUD
{
    public partial class SysAuth : Form
    {
        public SysAuth()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void SysAuth_Load(object sender, EventArgs e)
        {
            // TODO: 這行程式碼會將資料載入 'db1DataSet2.Auth' 資料表。您可以視需要進行移動或移除。
            this.authTableAdapter2.Fill(this.db1DataSet2.Auth);
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SysAuthNew authNew = new SysAuthNew();
            authNew.ShowDialog();
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            dataGridView1.Columns[0].ReadOnly = true;
            dataGridView1.Columns[6].ReadOnly = true;
            dataGridView1.Columns[7].ReadOnly = true;
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.authTableAdapter2.FillBy(this.db1DataSet2.Auth);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void orderByAccountToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.authTableAdapter2.OrderByAccount(this.db1DataSet2.Auth);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
