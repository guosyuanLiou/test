﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testwinCRUD
{
    public partial class SysPerson : Form
    {
        public SysPerson()
        {
            InitializeComponent();
        }

        private void checkBox1_Click(object sender, EventArgs e)
        {

        }

        private void SysPerson_Load(object sender, EventArgs e)
        {
            this.button1.Visible = false;
            this.button2.Visible = false;
        }

        private void checkBox1_MouseDown(object sender, MouseEventArgs e)
        {
            this.textBox3.Text = "1234567890";
            this.checkBox1.Checked = true;
        }

        private void checkBox1_MouseUp(object sender, MouseEventArgs e)
        {
            this.textBox3.Text = "**********";
            this.checkBox1.Checked = false;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            this.button1.Visible = true;
            this.button2.Visible = true;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            this.button1.Visible = true;
            this.button2.Visible = true;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            this.button1.Visible = true;
            this.button2.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
