﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testwinCRUD
{
    public partial class Form1 : Form
    {
        SysPerson person = null;
        SysAuth auth = null;
        SysData data = null;
        PersonAddcs personAdd = null;
        PersonSelectMul personSelMul = null;
        
        string Account = "";
        string Pws = "";
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

            DialogResult dialogresult = DialogResult.None;
            LogIn logIn = new LogIn();
            dialogresult = logIn.ShowDialog();
            if (dialogresult != DialogResult.None)
            {
                Account = logIn.Account;
                Pws = logIn.Pws;
                
            }
                
            if (DialogResult.OK == dialogresult)
            {
                label1.Text = Account;
            }
            else
            {
                
                this.Close();
            }
            person = new SysPerson();
            person.TopLevel = false;
            this.panel1.Controls.Add(person);
            auth = new SysAuth();
            auth.TopLevel = false;
            this.panel1.Controls.Add(auth);
            data = new SysData();
            data.TopLevel = false;
            this.panel1.Controls.Add(data);
            personAdd = new PersonAddcs();
            personAdd.TopLevel = false;
            this.panel1.Controls.Add(personAdd);
            personSelMul = new PersonSelectMul();
            personSelMul.TopLevel = false;
            this.panel1.Controls.Add(personSelMul);
        }

        private void 個人資料維護ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            auth.Hide();
            data.Hide();
            person.Show();
            personAdd.Hide();
            personSelMul.Hide();
        }

        private void 權限管控ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            auth.Show();
            data.Hide();
            person.Hide();
            personAdd.Hide();
            personSelMul.Hide();
        }

        private void 資料設定ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            auth.Hide();
            data.Show();
            person.Hide();
            personAdd.Hide();
            personSelMul.Hide();
        }

        private void 人才資料查詢多筆ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            auth.Hide();
            data.Hide();
            person.Hide();
            personAdd.Hide();
            personSelMul.Show();
        }

        private void 人才資料登錄ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            auth.Hide();
            data.Hide();
            person.Hide();
            personAdd.Show();
            personSelMul.Hide();
        }
    }
}
