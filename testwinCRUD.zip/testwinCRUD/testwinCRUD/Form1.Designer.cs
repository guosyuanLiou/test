﻿namespace testwinCRUD
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.人才資料管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.人才資料查詢多筆ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.人才資料登錄ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.人才資料查詢單筆ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.人才資料異動查詢ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.系統管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.個人資料維護ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.權限管控ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.資料設定ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.登出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(824, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.人才資料管理ToolStripMenuItem,
            this.系統管理ToolStripMenuItem,
            this.登出ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(893, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 人才資料管理ToolStripMenuItem
            // 
            this.人才資料管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.人才資料查詢多筆ToolStripMenuItem,
            this.人才資料登錄ToolStripMenuItem,
            this.人才資料查詢單筆ToolStripMenuItem,
            this.人才資料異動查詢ToolStripMenuItem});
            this.人才資料管理ToolStripMenuItem.Name = "人才資料管理ToolStripMenuItem";
            this.人才資料管理ToolStripMenuItem.Size = new System.Drawing.Size(92, 20);
            this.人才資料管理ToolStripMenuItem.Text = "人才資料管理";
            // 
            // 人才資料查詢多筆ToolStripMenuItem
            // 
            this.人才資料查詢多筆ToolStripMenuItem.Name = "人才資料查詢多筆ToolStripMenuItem";
            this.人才資料查詢多筆ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.人才資料查詢多筆ToolStripMenuItem.Text = "人才資料查詢(多筆)";
            this.人才資料查詢多筆ToolStripMenuItem.Click += new System.EventHandler(this.人才資料查詢多筆ToolStripMenuItem_Click);
            // 
            // 人才資料登錄ToolStripMenuItem
            // 
            this.人才資料登錄ToolStripMenuItem.Name = "人才資料登錄ToolStripMenuItem";
            this.人才資料登錄ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.人才資料登錄ToolStripMenuItem.Text = "人才資料登錄";
            this.人才資料登錄ToolStripMenuItem.Click += new System.EventHandler(this.人才資料登錄ToolStripMenuItem_Click);
            // 
            // 人才資料查詢單筆ToolStripMenuItem
            // 
            this.人才資料查詢單筆ToolStripMenuItem.Name = "人才資料查詢單筆ToolStripMenuItem";
            this.人才資料查詢單筆ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.人才資料查詢單筆ToolStripMenuItem.Text = "人才資料查詢(單筆)";
            // 
            // 人才資料異動查詢ToolStripMenuItem
            // 
            this.人才資料異動查詢ToolStripMenuItem.Name = "人才資料異動查詢ToolStripMenuItem";
            this.人才資料異動查詢ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.人才資料異動查詢ToolStripMenuItem.Text = "人才資料異動查詢";
            // 
            // 系統管理ToolStripMenuItem
            // 
            this.系統管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.個人資料維護ToolStripMenuItem,
            this.權限管控ToolStripMenuItem,
            this.資料設定ToolStripMenuItem});
            this.系統管理ToolStripMenuItem.Name = "系統管理ToolStripMenuItem";
            this.系統管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.系統管理ToolStripMenuItem.Text = "系統管理";
            // 
            // 個人資料維護ToolStripMenuItem
            // 
            this.個人資料維護ToolStripMenuItem.Name = "個人資料維護ToolStripMenuItem";
            this.個人資料維護ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.個人資料維護ToolStripMenuItem.Text = "個人資料維護";
            this.個人資料維護ToolStripMenuItem.Click += new System.EventHandler(this.個人資料維護ToolStripMenuItem_Click);
            // 
            // 權限管控ToolStripMenuItem
            // 
            this.權限管控ToolStripMenuItem.Name = "權限管控ToolStripMenuItem";
            this.權限管控ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.權限管控ToolStripMenuItem.Text = "權限管控";
            this.權限管控ToolStripMenuItem.Click += new System.EventHandler(this.權限管控ToolStripMenuItem_Click);
            // 
            // 資料設定ToolStripMenuItem
            // 
            this.資料設定ToolStripMenuItem.Name = "資料設定ToolStripMenuItem";
            this.資料設定ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.資料設定ToolStripMenuItem.Text = "資料設定";
            this.資料設定ToolStripMenuItem.Click += new System.EventHandler(this.資料設定ToolStripMenuItem_Click);
            // 
            // 登出ToolStripMenuItem
            // 
            this.登出ToolStripMenuItem.Name = "登出ToolStripMenuItem";
            this.登出ToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.登出ToolStripMenuItem.Text = "登出";
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(0, 27);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(893, 509);
            this.panel1.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(893, 561);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 人才資料管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 人才資料查詢多筆ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 人才資料登錄ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 人才資料查詢單筆ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 人才資料異動查詢ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 系統管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 個人資料維護ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 權限管控ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 資料設定ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 登出ToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
    }
}

